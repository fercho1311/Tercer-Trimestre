package Ejercicio1;

import java.util.Random;
import java.util.ArrayList;

public class Principal{


    private static void main(String[] args) {
     
        System.out.println("Se van a generar 10 números al azar");

        Random r = new Random()
        ArrayList<String> numeros = new ArrayList<>()
        
        for(int i = 0; i<10 ; i++){
            numeros.add(r.nextInt(100));
        }
    
        for(int i = 0; i<=10 ; i++){
            Integer actual = numeros.get(i);
            if(actual  % 2 == 0){
                System.out.println("El número "+actual+" es impar");
            }else{
                System.out.println("El número "+actual+" es par");
            }
        }

        System.out.println("Solucionado el ejercicio 1");
    }

}